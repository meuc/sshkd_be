For a more detailed documentation please go to: 

http://helpdesk.themetwins.com/